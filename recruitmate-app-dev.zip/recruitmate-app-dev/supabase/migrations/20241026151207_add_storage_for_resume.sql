insert into
    storage.buckets (id, name, public)
values
    ('resumes', 'resumes', false);