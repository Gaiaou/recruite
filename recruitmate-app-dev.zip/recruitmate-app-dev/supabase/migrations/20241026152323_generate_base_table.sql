-- Create recruiters table
CREATE TABLE recruiters (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create campaigns table
CREATE TABLE campaigns (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    email_subject VARCHAR(255),
    email_body TEXT,
    start_date DATE,
    end_date DATE,
    status VARCHAR(255) DEFAULT 'inactive',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by_id INT
);

-- Create candidates table
CREATE TABLE candidates (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    phone VARCHAR(20),
    resume TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create campaign_recruiters table
CREATE TABLE campaigns_recruiters (
    id SERIAL PRIMARY KEY,
    campaign_id INT,
    recruiter_id INT,
    FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
    FOREIGN KEY (recruiter_id) REFERENCES recruiters(id)
);

-- Create campaign_candidates table
CREATE TABLE campaigns_candidates (
    id SERIAL PRIMARY KEY,
    campaign_id INT,
    candidate_id INT,
    previewed BOOLEAN DEFAULT false,
    email_sent BOOLEAN DEFAULT false,
    email_opened BOOLEAN DEFAULT false,
    email_clicked BOOLEAN DEFAULT false,
    email_subject VARCHAR(255),
    email_body TEXT,
    FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id)
);