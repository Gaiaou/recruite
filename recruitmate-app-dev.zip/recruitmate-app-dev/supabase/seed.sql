-- Insert data into recruiters table
INSERT INTO
    recruiters (email, password, first_name, last_name)
VALUES
    (
        'john.doe@google.com',
        'password123',
        'John',
        'Doe'
    ),
    (
        'jane.smith@amazon.com',
        'password123',
        'Jane',
        'Smith'
    ),
    (
        'michael.johnson@microsoft.com',
        'password123',
        'Michael',
        'Johnson'
    ),
    (
        'emily.davis@facebook.com',
        'password123',
        'Emily',
        'Davis'
    ),
    (
        'david.wilson@apple.com',
        'password123',
        'David',
        'Wilson'
    );

-- Insert data into campaigns table
INSERT INTO
    campaigns (
        name,
        description,
        email_subject,
        email_body,
        start_date,
        end_date,
        status
    )
VALUES
    (
        'Google Frontend Developer Recruitment',
        'Recruitment campaign for frontend developers at Google',
        'Join Google as a Frontend Developer',
        'Google is looking for skilled frontend developers to join their team. Apply now!',
        '2023-10-01',
        '2023-12-31',
        'active'
    ),
    (
        'Amazon Backend Developer Recruitment',
        'Recruitment campaign for backend developers at Amazon',
        'Backend Developer Position at Amazon',
        'Amazon is seeking experienced backend developers. Apply today!',
        '2023-09-15',
        '2023-11-30',
        'active'
    ),
    (
        'Microsoft Full Stack Developer Recruitment',
        'Recruitment campaign for full stack developers at Microsoft',
        'Full Stack Developer Opportunity at Microsoft',
        'Join Microsoft as a full stack developer. Apply now!',
        '2023-08-01',
        '2023-10-31',
        'inactive'
    ),
    (
        'Facebook DevOps Engineer Recruitment',
        'Recruitment campaign for DevOps engineers at Facebook',
        'DevOps Engineer Wanted at Facebook',
        'Facebook is hiring DevOps engineers to streamline their operations. Apply now!',
        '2023-07-01',
        '2023-09-30',
        'inactive'
    ),
    (
        'Apple Data Scientist Recruitment',
        'Recruitment campaign for data scientists at Apple',
        'Data Scientist Position Available at Apple',
        'Apple is looking for talented data scientists to join their team. Apply now!',
        '2023-06-01',
        '2023-08-31',
        'inactive'
    );

-- Insert data into candidates table
INSERT INTO
    candidates (email, first_name, last_name, phone, resume)
VALUES
    (
        'alice.brown@gmail.com',
        'Alice',
        'Brown',
        '123-456-7890',
        'Resume content for Alice Brown'
    ),
    (
        'bob.jones@gmail.com',
        'Bob',
        'Jones',
        '234-567-8901',
        'Resume content for Bob Jones'
    ),
    (
        'charlie.miller@gmail.com',
        'Charlie',
        'Miller',
        '345-678-9012',
        'Resume content for Charlie Miller'
    ),
    (
        'diana.evans@gmail.com',
        'Diana',
        'Evans',
        '456-789-0123',
        'Resume content for Diana Evans'
    ),
    (
        'edward.moore@gmail.com',
        'Edward',
        'Moore',
        '567-890-1234',
        'Resume content for Edward Moore'
    );

-- Insert data into campaign_recruiters table
INSERT INTO
    campaigns_recruiters (campaign_id, recruiter_id)
VALUES
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5);

INSERT INTO
    campaigns_candidates (campaign_id, candidate_id)
VALUES
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5);