// https://nuxt.com/docs/api/configuration/nuxt-config
import Aura from '@primevue/themes/aura'
import { definePreset } from '@primevue/themes'

const CustomPreset = definePreset(Aura, {
  primitive: {
    blue: { 500: '#37AFE1', 600: '#4CC9FE' },
    yellow: { 100: '#fffff7', 200: '#fdffe7', 300: '#e3f1ff' }
  },
  semantic: {
    primary: {
      500: '{blue.500}',
      600: '{blue.600}',
    },
  },
})

export default defineNuxtConfig({
  compatibilityDate: '2024-04-03',
  devtools: { enabled: true },
  modules: ['@nuxtjs/supabase', '@nuxt/eslint', '@primevue/nuxt-module'],
  supabase: {
    redirect: false,
  },
  ssr: false,
  components: [
    {
      path: '~/components', // will get any components nested in let's say /components/test too
      pathPrefix: false,
    },
  ],

  css: ['@/assets/global.scss', 'primeicons/primeicons.css'],
  vite: {
    css: {
      preprocessorOptions: {
        scss: {
          api: 'modern',
          additionalData: '@use "@/assets/theme.scss" as *;',
        },
      },
    },
  },
  primevue: {
    options: {
      theme: {
        preset: CustomPreset,
        options: {
          prefix: 'p',
          darkModeSelector: false || 'none',
          cssLayer: false,
        },
      },
    },
  },
})
