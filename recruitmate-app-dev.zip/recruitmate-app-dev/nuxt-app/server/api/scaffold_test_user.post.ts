/*
    scaffold_test_user.post.ts
    This file is used to scaffold a test user for the app.

*/

import { serverSupabaseClient } from "#supabase/server";
export default defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient<Database>(event);

  const testUsers = [
    { email: "lan.ng.1991@gmail.com", password: "recruitmateai" },
    { email: "rh@robx.tech", password: "recruitmateai" },
    { email: "linhnguyendeveloper@gmail.com", password: "recruitmateai" },
  ];

  for (const user of testUsers) {
    const { data, error } = await supabase.auth.admin.createUser({
      email: user.email,
      password: user.password,
      email_confirm: true,
    });

    if (error) {
      console.error(`Error creating user ${user.email}:`, error.message);
    } else {
      console.log(`User created:`, data);
    }
  }
});
