/*
  This function sends an email to a candidate using Postmark API
  base on the candidate_id and campaign_id provided in the request body
  Note: Right now we are using 1 email template From Address
  This could change in the future to support multiple email sender

  POST /api/send_email
  {
    "candidate_id": "candidate_id",
    "campaign_id": "campaign_id"
  }
*/

import postmark from "postmark";
import { serverSupabaseClient } from "#supabase/server";
import { useCandidateService } from "~/composables/useCandidateService";
import { useCampaignService } from "~/composables/useCampaignService";
import { Tables } from "#supabase/database";
import mammoth from "mammoth";
import OpenAI from "openai";

const apiToken = process.env.POSTMARK_SERVER_API_TOKEN;
const openAIToken = process.env.OPENAI_API_KEY;

if (!apiToken) {
  throw new Error("POSTMARK_SERVER_API_TOKEN is not defined");
}

if (!openAIToken) {
  throw new Error("OPENAI_API_KEY is not defined");
}

const client = new postmark.ServerClient(apiToken);
const openai = new OpenAI({
  apiKey: openAIToken,
});

export function validate(
  candiate: Tables<"candidates">,
  campaign: Tables<"campaigns">
) {
  if (!candiate) {
    throw createError({
      statusCode: 404,
      statusMessage: "Candidate not found",
    });
  }

  if (!campaign) {
    throw createError({
      statusCode: 404,
      statusMessage: "Campaign not found",
    });
  }

  if (!candiate.email) {
    throw createError({
      statusCode: 404,
      statusMessage: "Candidate email is missing",
    });
  }

  if (!campaign.email_subject) {
    throw createError({
      statusCode: 400,
      statusMessage: "Campaign email_subject is missing",
    });
  }
}

async function extractTextFromBinaryDocx(fileBuffer: Buffer) {
  try {
    const { value: text } = await mammoth.extractRawText({
      buffer: fileBuffer,
    });
    return text;
  } catch (error) {
    console.error("Error extracting text:", error);
  }
}

export default defineEventHandler(async (event) => {
  const supabase = await serverSupabaseClient<Database>(event);
  const candidateService = useCandidateService(supabase);
  const campaignService = useCampaignService(supabase);

  const body = await readBody(event);
  const { candidate_id, campaign_id } = body;

  try {
    const candidate = await candidateService.getCandidateById(candidate_id);
    const campaign = await campaignService.getCampaignById(campaign_id);

    validate(candidate, campaign);

    const { data, error } = await supabase.storage
      .from("resumes")
      .download(candidate.resume!);

    if (error) {
      throw createError({
        statusCode: 500,
        statusMessage: "Error downloading resume",
      });
    }

    const fileBuffer = await data.arrayBuffer();
    const resumeText = await extractTextFromBinaryDocx(Buffer.from(fileBuffer));

    console.log("Resume text:", resumeText);

    // await client.sendEmail({
    //   From: "outreach@recruitmateai.com",
    //   To: candidate.email,
    //   Subject: campaign.email_subject!,
    //   TextBody: `This is a notification for campaign ID: ${campaign_id}`,
    // });

    return {
      message: `Email sent to ${candidate.email}`,
    };
  } catch (error) {
    console.error("Error sending email:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Error sending email",
    });
  }
});
