<script lang="ts" setup>
const supabase = useSupabaseClient<Database>();
const email = ref("");
const password = ref("");

async function signInWithEmail() {
  if (!email.value || !password.value) {
    alert("Please enter your email and password");
    return;
  }

  const { data, error } = await supabase.auth.signInWithPassword({
    email: email.value,
    password: password.value,
  });

  if (error) {
    alert(error.message);
    return;
  }

  navigateTo("/");
}
</script>
<template>
  <input type="text" v-model="email" />
  <input type="password" v-model="password" />

  <button @click="signInWithEmail">Login with Email</button>
</template>

<style scoped></style>
