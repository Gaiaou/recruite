<script setup lang="ts">
import { ref, computed } from "vue";
const client = useSupabaseClient();
const router = useRouter();

// Fetch campaigns data from Supabase
const { data: campaigns } = await client
  .from("campaigns")
  .select("*")
  .limit(10);

// Define search input state
const searchTerm = ref("");

// Compute filtered campaigns based on the search term
const filteredCampaigns = computed(() => {
  if (!campaigns) return [];
  const lowerCaseSearchTerm = searchTerm.value.toLowerCase();
  return campaigns.filter((campaign) =>
    JSON.stringify(Object.values(campaign))
      .toLowerCase()
      .includes(lowerCaseSearchTerm),
  );
});
</script>

<template>
  <div class="campaigns">
    <div class="campaigns__top">
      <div class="campaigns__heading">
        <h1 class="campaigns__title">Your campaigns</h1>
        <p class="campaigns__description">
          View the status of your outreach campaigns and manage your pipeline.
          Use templates to send personalized emails in bulk.
        </p>
      </div>
      <div class="campaigns__action">
        <div class="campaigns__action__input-container">
          <IconField>
            <InputIcon class="pi pi-search" />
            <InputText v-model="searchTerm" placeholder="Search" />
          </IconField>
        </div>

        <NuxtLink to="/begin-campaign">
          <Button
            icon="pi pi-plus"
            label="New campaign"
            severity="primary"
            class="campaigns__begin-button"
          />
        </NuxtLink>
      </div>
    </div>

    <div
      v-for="campaign in filteredCampaigns"
      :key="campaign.id"
      class="campaigns__card"
    >
      <CampaignCard :campaign="campaign" />
    </div>
  </div>
</template>

<style scoped lang="scss">
// Define SCSS variables
$card-title-font-size: 28px;
$card-title-padding-left: $card-padding-body;
$description-color: var(--p-surface-500);
$button-margin: 16px auto;

.campaigns {
  max-width: 1280px;
  margin: 0 auto;
  padding: 36px 0;

  &__top {
    display: flex;
    gap: 100px;
    @include breakpoint(large) {
      display: block;
    }
  }

  &__heading {
    padding: 0 $card-title-padding-left;
    margin-bottom: 12px;
  }

  &__title {
    font-size: $card-title-font-size;
    @include breakpoint(small) {
      line-height: 140%;
    }
  }

  &__description {
    color: $description-color;
    margin: 4px 0 0;
    font-weight: 400;
    @include breakpoint(small) {
      line-height: 140%;
    }
  }

  &__action {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    width: 50%;
    padding: 0 $card-title-padding-left;
    margin-bottom: 42px;
    @include breakpoint(large) {
      display: block;
      width: 100%;
      margin-top: 36px;
    }

    &__input-container {
      flex: 1;
      :deep(.p-inputtext) {
        width: 100%;
      }
    }
  }

  &__begin-button {
    display: flex;
    margin: $button-margin;
    @include breakpoint(large) {
      width: 100%;
    }
  }
  &__card:nth-child(even) {
    @include breakpoint(small) {
      background: $card-hover-bg;
    }
  }
}
</style>
