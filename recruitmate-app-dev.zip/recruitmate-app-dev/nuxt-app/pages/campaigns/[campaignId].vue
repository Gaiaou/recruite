<template>
  <div class="test" v-if="campaign">
    {{ $route.params.campaignId }}

    campaign is:

    {{ campaign }}
  </div>
</template>

<script setup lang="ts">
const client = useSupabaseClient<Database>();
const campaignId = useRoute().params.campaignId;

const { data: campaign } = await client
  .from("campaigns")
  .select("*")
  .eq("id", campaignId);
</script>

<style scoped></style>
