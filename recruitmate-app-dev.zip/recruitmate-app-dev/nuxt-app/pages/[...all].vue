<template>
    <div>
        404 catch all
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>