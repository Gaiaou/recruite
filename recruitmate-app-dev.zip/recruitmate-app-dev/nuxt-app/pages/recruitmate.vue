<script setup lang="ts">
const client = useSupabaseClient<Database>();

const { data: campaigns } = await client
  .from("campaigns")
  .select("*")
  .limit(10);
</script>
<template>
  <div>
    <div class="campaign-card" v-for="campaign in campaigns">
      {{ campaign }}
    </div>
  </div>
</template>

<style scoped></style>
