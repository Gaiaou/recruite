<template>
    <NuxtPage/> 
</template>
