import { SupabaseClient } from "@supabase/supabase-js";

export const useCampaignService = (supabase: SupabaseClient<Database>) => {
  // helper function to get a campaign by its id
  const getCampaignById = async (id: string) => {
    const { data, error } = await supabase
      .from("campaigns")
      .select("*")
      .eq("id", id)
      .single();

    if (error) {
      throw error;
    }

    return data;
  };

  return {
    getCampaignById,
  };
};
