import { SupabaseClient } from "@supabase/supabase-js";

export const useCandidateService = (supabase: SupabaseClient<Database>) => {
  // helper function to get a candidate by its id
  const getCandidateById = async (id: string) => {
    const { data, error } = await supabase
      .from("candidates")
      .select("*")
      .eq("id", id)
      .single();

    if (error) {
      throw error;
    }

    return data;
  };

  return {
    getCandidateById,
  };
};
