import { useRouter } from "vue-router";
import type {
  AuthChangeEvent,
  Session,
  SupabaseClient,
} from "@supabase/supabase-js";

export default defineNuxtPlugin((nuxtApp) => {
  const supabase = useSupabaseClient<SupabaseClient>();
  const router = useRouter();

  supabase.auth.onAuthStateChange(
    (event: AuthChangeEvent, session: Session | null) => {
      if (event === "SIGNED_IN") {
        // router.push("/"); // Redirect to home page after login
      }
    }
  );
});
