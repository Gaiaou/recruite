import type { Database as SupabaseDatabase } from "./database.types";

declare global {
  type Database = SupabaseDatabase;
}

export {};
