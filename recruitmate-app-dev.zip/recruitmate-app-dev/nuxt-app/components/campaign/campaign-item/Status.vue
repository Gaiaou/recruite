<script setup lang="ts">
enum StatusEnum {
  ACTIVE = "active",
  INACTIVE = "inactive",
  PENDING = "pending",
  COMPLETED = "completed",
}

const props = defineProps<{
  status: StatusEnum;
}>();

const statusText = computed(() => {
  switch (props.status) {
    case StatusEnum.ACTIVE:
      return "Ongoing";
    case StatusEnum.INACTIVE:
      return "Ended";
    case StatusEnum.PENDING:
      return "Pending";
    case StatusEnum.COMPLETED:
      return "Completed";
    default:
      return "Unknown";
  }
});

const statusClass = computed(() => {
  switch (props.status) {
    case StatusEnum.ACTIVE:
      return "status--active";
    case StatusEnum.INACTIVE:
      return "status--inactive";
    case StatusEnum.PENDING:
      return "status--pending";
    case StatusEnum.COMPLETED:
      return "status--completed";
    default:
      return "status--unknown";
  }
});
</script>

<template>
  <div :class="`status ${statusClass}`">{{ statusText }}</div>
</template>

<style scoped lang="scss">
// Define SCSS variables for each status color
$active-color: var(--p-slate-600);
$inactive-color: var(--p-red-400);
$pending-color: var(--p-orange-400);
$completed-color: var(--p-green-400);
$unknown-color: var(--p-gray-400);

.status {
  &--active {
    color: $active-color;
  }
  &--inactive {
    color: $inactive-color;
  }
  &--pending {
    color: $pending-color;
  }
  &--completed {
    color: $completed-color;
  }
  &--unknown {
    color: $unknown-color;
  }
}
</style>
