<script setup lang="ts">
const getImageUrl = () => {
  switch (id % 4) {
    case 1:
      return "/img/thumbnail1.png";
    case 2:
      return "/img/thumbnail2.png";
    case 3:
      return "/img/thumbnail3.png";
    default:
      return "/img/thumbnail4.png";
  }
};
const props = defineProps({
  campaign: {
    status: String,
    name: String,
    description: String,
  },
});
const { status, name, description, id } = props.campaign;
const router = useRouter();

// Check if description has more than 9 words
const isLongDescription = computed(() => {
  return description ? description.split(" ").length > 9 : false;
});

const getTitle = computed(() => {
  return isLongDescription ? description : "";
});

// Truncate the description to 9 words and add "..." if it exceeds 9 words
const getTruncatedDescription = computed(() => {
  if (!description) return "";
  const words = description.split(" ");
  return words.length > 9 ? words.slice(0, 9).join(" ") + "..." : description;
});

const handleClickViewCandidates = () => {
  router.push("/campaigns/" + id);
};
</script>

<template>
  <NuxtLink :to="`/campaigns/${id}`">
    <div class="campaign-card">
      <Card>
        <template #header>
          <Status :status="status" />
        </template>
        <template #title>
          <p>{{ name }}</p>
        </template>
        <template #subtitle>
          <p
            v-tooltip.bottom="{
              value: getTitle,
              pt: {
                root: {
                  style: {
                    maxWidth: '400px',
                  },
                },
              },
            }"
          >
            {{ getTruncatedDescription }}
          </p>
        </template>
        <template #content>
          <Button
            label="View candidates"
            severity="secondary"
            @click="handleClickViewCandidates"
          />
        </template>
      </Card>
      <Card class="campaign-card__image-wrapper">
        <template #content>
          <img
            :src="getImageUrl()"
            alt="card image"
            class="campaign-card__image"
          />
        </template>
      </Card>
    </div>
  </NuxtLink>
</template>

<style scoped lang="scss">
// Define SCSS variables
$card-image-radius: 8px;
$card-image-width: 300px;
$card-header-padding: 16px;
$card-body-gap: 24px;
$card-image-top-padding: 24px;

.campaign-card {
  display: flex;
  justify-content: space-between;
  padding: 24px $card-padding-body;
  gap: 24px;
  cursor: pointer;
  transition: background 0.2s ease;

  &:hover {
    background: $card-hover-bg;
  }

  @include breakpoint(small) {
    display: block;
  }

  .p-card {
    box-shadow: none;
    background: transparent;

    :deep(.p-card-body) {
      padding: 0;
      gap: $card-body-gap;
    }
    :deep(.p-card-title) {
      color: var(--p-gray-950);
      font-weight: 500 !important;
    }
    :deep(.p-button) {
      background-color: #fdffe7;
      border: 1px solid #e3f1ff;
    }
    :deep(.p-card-subtitle) p {
      @include breakpoint(small) {
        line-height: 130%;
      }
    }
  }

  &__image {
    border-radius: $card-image-radius;
    width: $card-image-width;
  }

  &__image-wrapper.p-card {
    @include breakpoint(small) {
      padding-top: $card-image-top-padding;
    }
  }

  .status {
    margin-bottom: 5px;
    font-weight: 200;
  }
}
</style>
